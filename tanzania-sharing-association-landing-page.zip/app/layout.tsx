import React from "react"
import type { Metadata, Viewport } from 'next'
import { Inter, Playfair_Display } from 'next/font/google'

import './globals.css'

const _inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const _playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair' })

export const metadata: Metadata = {
  title: 'Tanzania Sharing Association | Texas Diaspora Mutual-Aid Society',
  description: 'The Tanzania Sharing Association (TSA) is a Texas-based diaspora mutual-aid society uniting Tanzanians in America through community support, cultural preservation, and shared prosperity.',
}

export const viewport: Viewport = {
  themeColor: '#2E9E3E',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
