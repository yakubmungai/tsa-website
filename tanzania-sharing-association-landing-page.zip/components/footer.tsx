export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <a href="#" className="flex items-center gap-3">
              <img
                src="/images/tsa-logo.png"
                alt="Tanzania Sharing Association Logo"
                className="h-12 w-12 rounded-full"
              />
              <div>
                <p className="font-semibold text-foreground leading-tight">Tanzania Sharing</p>
                <p className="font-semibold text-foreground leading-tight">Association</p>
              </div>
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              A Texas-based diaspora mutual-aid society uniting Tanzanians in America
              through community support and cultural preservation.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-foreground">
              Quick Links
            </h4>
            <ul className="mt-4 flex flex-col gap-3">
              {[
                { label: "About Us", href: "#about" },
                { label: "Programs", href: "#programs" },
                { label: "Events", href: "#events" },
                { label: "Membership", href: "#membership" },
              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-foreground">
              Resources
            </h4>
            <ul className="mt-4 flex flex-col gap-3">
              {[
                { label: "Constitution", href: "#" },
                { label: "Meeting Minutes", href: "#" },
                { label: "Financial Reports", href: "#" },
                { label: "FAQs", href: "#" },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-foreground">
              Connect
            </h4>
            <ul className="mt-4 flex flex-col gap-3">
              {[
                { label: "Facebook", href: "#" },
                { label: "WhatsApp Group", href: "#" },
                { label: "Email Us", href: "#contact" },
                { label: "Call Us", href: "#contact" },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 sm:flex-row">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Tanzania Sharing Association. All rights reserved.
          </p>
          <div className="flex h-1.5 w-24 overflow-hidden rounded-full">
            <div className="flex-1 bg-[hsl(133,55%,40%)]" />
            <div className="flex-1 bg-[hsl(200,72%,55%)]" />
            <div className="flex-1 bg-[hsl(45,92%,53%)]" />
            <div className="flex-1 bg-foreground" />
          </div>
        </div>
      </div>
    </footer>
  )
}
